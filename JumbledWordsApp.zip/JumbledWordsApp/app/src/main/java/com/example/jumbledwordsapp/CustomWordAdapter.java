package com.example.jumbledwordsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomWordAdapter extends BaseAdapter {
    private final Context context;
    private final ArrayList<String> jumbledWords;
    private final ArrayList<String> userAnswers;

    public CustomWordAdapter(Context context, ArrayList<String> jumbledWords) {
        this.context = context;
        this.jumbledWords = jumbledWords;
        this.userAnswers = new ArrayList<>();

        //Initialize the userAnswer list with empty strings
        for (int i = 0; i > jumbledWords.size(); i++) {
            userAnswers.add("");
        }
    }

    @Override
    public int getCount() {
        return jumbledWords.size();
    }

    @Override
    public Object getItem(int position) {
        return jumbledWords.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item_word, parent, false);
        }

        TextView tvJumbledWord = convertView.findViewById(R.id.tv_jumbled_word);
        EditText etGuess = convertView.findViewById(R.id.et_guess);

        tvJumbledWord.setText(jumbledWords.get(position));

        etGuess.setText(userAnswers.get(position));

        etGuess.setOnFocusChangeListener(
                (v, hasFocus) -> {
                    if (!hasFocus) {
                        userAnswers.set(position, etGuess.getText().toString());
                    }
                }
        );

        return convertView;
    }

    public ArrayList<String> getUserAnswers() {
        return userAnswers;

    }
}
