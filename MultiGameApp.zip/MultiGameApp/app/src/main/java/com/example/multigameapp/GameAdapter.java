package com.example.multigameapp;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class GameAdapter extends BaseAdapter {

    //Class variables
    private final Context context;
    private final String[] board;

    public GameAdapter(Context context, String[] board) {
        this.context = context;
        this.board = board;
    }

    //Tells the GV how many items there are in the board array
    @Override
    public int getCount() {
        return board.length;
    }

    //Returns a unique ID for each item
    @Override
    public Object getItem(int position) {
        return board[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    //Where all the ✨magic✨ happens
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView cell;

        if(convertView == null) {
            cell = new TextView(context);

            //Creates a 200x200 pixel cell
            cell.setLayoutParams(new ViewGroup.LayoutParams(200, 200));

            cell.setTextSize(24);

            cell.setGravity(android.view.Gravity.CENTER);

            //Add a border to the grid
            cell.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);

        } else {
            //Reuse the pre-existing resource to save up on memory
            cell = (TextView) convertView;
        }

        //Displays the current value of the board at the given position
        cell.setText(board[position]);

        return cell;
    }
}

