package com.example.multigameapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Arrays;

public class JumbledWordActivity extends AppCompatActivity {

    private ListView lvWords;
    private TextView tvTimer;
    private Button btnSubmit;

    private final ArrayList<String> words = new ArrayList<>(Arrays.asList("cavite", "rizal", "laguna"));
    private final ArrayList<String> jumbledWords = new ArrayList<>(Arrays.asList("etivac", "zalri", "gulana"));

    private CustomWordAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_jumbled_words);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnBack = findViewById(R.id.btn_back);

        btnBack.setOnClickListener(
                v -> {
                    Intent intent = new Intent(JumbledWordActivity.this, MainMenuActivity.class);
                    startActivity(intent);
                }
        );

        //Find the views by ID
        lvWords = findViewById(R.id.lv_words);
        tvTimer = findViewById(R.id.tv_timer);
        btnSubmit = findViewById(R.id.btn_submit);

        //Initialize the custom adapter and set it the list view
        adapter = new CustomWordAdapter(this, jumbledWords);
        lvWords.setAdapter(adapter);

        startTimer(60);

        btnSubmit.setOnClickListener(
                v -> checkAnswers(adapter.getUserAnswers())
        );
    }

    private void startTimer(int seconds) {
        new CountDownTimer(seconds * 1000, 1000) {
            public void onTick(long milisUntilFinished) {
                //Update the timer ever second
                tvTimer.setText("Time Left: " + milisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                tvTimer.setText("Times Up!");
                btnSubmit.setEnabled(false);
                checkAnswers(adapter.getUserAnswers());
            }
        }.start();
    }

    private void checkAnswers(ArrayList<String> userAnswers) {
        int correctCount = 0;

        for (int i = 0; i < words.size(); i++) {
            if (userAnswers.get(i).equalsIgnoreCase(words.get(i))) {
                correctCount++;
            }
        }
        Toast.makeText(this, "You got " + correctCount + " out of " + words.size(), Toast.LENGTH_SHORT).show();
    }


}

