package com.example.multigameapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TicTacToeActivity extends AppCompatActivity {

    //Class variables

    private String[] board = new String[9];
    private boolean isPlayerX = true;

    private boolean gameActive = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tic_tac_toe);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnBack = findViewById(R.id.btn_back);

        btnBack.setOnClickListener(
                v -> {
                    Intent intent = new Intent(TicTacToeActivity.this, MainMenuActivity.class);
                    startActivity(intent);
                }
        );

        GridView gvGame = findViewById(R.id.gv_game);

        TextView tvTitle = findViewById(R.id.tv_title);

        //Starts the game with an empty board
        for (int i = 0; i < board.length; i++) {
            board[i] = "";
        }

        GameAdapter adapter = new GameAdapter(this, board);
        gvGame.setAdapter(adapter);

        gvGame.setOnItemClickListener(
                (parent, view, position, id) -> {
                    if (!gameActive || !board[position].isEmpty()) {
                        return;
                    }

                    board[position] = isPlayerX ? "X" : "0";

                    //Switch turns
                    isPlayerX = !isPlayerX;

                    //Refresh the grid to show the updated state of the board
                    adapter.notifyDataSetChanged();

                    String winner = checkWinner();

                    if (winner != null) {
                        gameActive = false;

                        tvTitle.setText(winner.equals("Draw") ? "It's a draw" : winner + "Wins!");
                        Toast.makeText(this, winner.equals("Draw") ? "It's a draw!" : winner + "Wins!", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    private String checkWinner() {
        //Winning combos
        String[][] winningCombos = {
                //Rows
                {"0", "1", "2"},
                {"3", "4", "5"},
                {"6", "7", "8"},

                //Coloumns
                {"0", "3", "6"},
                {"1", "4", "7"},
                {"2", "5", "8"},

                //Diagonal
                {"0", "4", "8"},
                {"2", "4", "6"}
        };
        for(String[] combos : winningCombos) {
            //Values of the three cells in the current combos
            String cell1 = board[Integer.parseInt(combos[0])];
            String cell2 = board[Integer.parseInt(combos[1])];
            String cell3 = board[Integer.parseInt(combos[2])];

            //If all three cells are the same and not empty, end game
            if(!cell1.isEmpty() && cell1.equals(cell2) && cell1.equals(cell3)) {
                return cell1;
            };
        }

        for (String cell: board) {
            if (cell.isEmpty()) {
                return null;
            }
        }

        return "Draw";
    }
}
