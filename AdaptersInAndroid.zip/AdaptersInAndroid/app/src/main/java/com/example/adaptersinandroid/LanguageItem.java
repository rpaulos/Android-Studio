package com.example.adaptersinandroid;

public class LanguageItem {

    private int logoResID;
    private String name;
    public LanguageItem(int logoResId, String name) {
        this.logoResID = logoResId;
        this.name = name;
    }

    //Getter for logo resource Id
    public int getLogoResID() {
        return logoResID;
    }

    //Getter for name resource Id
    public String getName() {
        return name;
    }
}
