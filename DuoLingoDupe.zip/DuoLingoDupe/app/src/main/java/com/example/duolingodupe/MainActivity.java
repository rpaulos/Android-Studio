package com.example.duolingodupe;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //Class Variable
    private MediaPlayer mediaplayer;
    private Button btnHello, btnGoodBye, btnThankYou, btnMorning, btnAfternoon, btnNight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnHello = findViewById(R.id.btn_hello);
        btnGoodBye = findViewById(R.id.btn_goodbye);
        btnThankYou = findViewById(R.id.btn_thank_you);
        btnMorning = findViewById(R.id.btn_good_morning);
        btnAfternoon = findViewById(R.id.btn_good_afternoon);
        btnNight = findViewById(R.id.btn_good_night);

        /*
        btnHello.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.hello);
            }
        });

        btnThankYou.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.thankyou);
            }
        });

        btnGoodBye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.goodbye);
            }
        });

        btnMorning.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.morning);
            }
        });

        btnAfternoon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.afternoon);
            }
        });

        btnNight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playSound(R.raw.night);
            }
        });
         */
    }

    private void playSound(int soundSource) {
        if (mediaplayer != null) {
            mediaplayer.release();
        }

        //Initialize mediaPlayer with the selected sound
        mediaplayer = mediaplayer.create(this, soundSource);
        mediaplayer.start();
    }

    @Override
    protected void onDestroy() {
        //Release MediaPlayer resources when played
        super.onDestroy();
        if (mediaplayer != null) {
            mediaplayer.release();
            mediaplayer = null;
        }
    }
}