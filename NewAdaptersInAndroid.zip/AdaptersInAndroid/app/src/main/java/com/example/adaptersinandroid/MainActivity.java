package com.example.adaptersinandroid;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Create a list of programming languages with their logo
        ArrayList<LanguageItem> languageList = new ArrayList<>();

        languageList.add(new LanguageItem(R.drawable.java_logo, "Java"));
        languageList.add(new LanguageItem(R.drawable.python_logo, "Python"));
        languageList.add(new LanguageItem(R.drawable.cpp_logo, "C++"));
        languageList.add(new LanguageItem(R.drawable.kotlin_logo, "Kotlin"));
        languageList.add(new LanguageItem(R.drawable.js_logo, "JavaScript"));
        languageList.add(new LanguageItem(R.drawable.swift_logo, "Swift"));
        languageList.add(new LanguageItem(R.drawable.sql_logo, "SQL"));

        //Create an instance of the custom adapter
        LanguageAdapter adapter = new LanguageAdapter(this, languageList);

        //Find the list view in the layout and set the custom adapter
        ListView lvList = findViewById(R.id.lv_list);
        lvList.setAdapter(adapter);

        //Add a click listener
        lvList.setOnItemClickListener((parent, view, position, id) -> {
            //Get the selected language
            LanguageItem selectedLanguage = (LanguageItem) adapter.getItem(position);

            //Show a toast message
            String message = "You selected " + selectedLanguage.getName();
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

        });

    }
}