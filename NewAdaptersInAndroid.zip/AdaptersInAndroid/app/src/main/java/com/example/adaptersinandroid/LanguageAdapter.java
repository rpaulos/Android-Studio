package com.example.adaptersinandroid;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class LanguageAdapter extends BaseAdapter {

    private Context context; //Access app resources
    private ArrayList<LanguageItem> languageList; //Data to display

    //Constructor to initialize the adapter  with the context and the data
    public LanguageAdapter(Context context, ArrayList<LanguageItem> languageList) {
        this.context = context;
        this. languageList = languageList;
    }

    @Override
    public int getCount() {
        return languageList.size();
    }

    @Override
    public Object getItem(int position) {
        return languageList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            //Inflates the custom layout for each row
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        //Get current language item
        LanguageItem currentItem = (LanguageItem) getItem(position);

        //Find and bind the logo
        ImageView logoImage = convertView.findViewById(R.id.iv_logo);
        logoImage.setImageResource(currentItem.getLogoResID());

        //Bind the name to the TextView
        TextView languageName = convertView.findViewById(R.id.tv_language);
        languageName.setText(currentItem.getName());

        return convertView;
    }
}
